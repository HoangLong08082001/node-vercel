const { authenticationToken } = require("../../middleware/JwtAction");

const { getOrdersByReferralLink } = require("./OrdersController");

const express = require("express");
const router = express.Router();
module.exports = function OrdersRoutes(app) {
  router.get("/get-order-by/:id", authenticationToken, getOrdersByReferralLink);
  return app.use("/orders", router);
};
