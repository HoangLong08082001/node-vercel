const { authenticationToken } = require("../../middleware/JwtAction");
const {
  checkPermission,
  createDepartment,
  getAlDepartment,
  getDepartmentWithRule,
} = require("./DepartmentConrtoller");

const express = require("express");
const router = express.Router();
module.exports = function DepartmentRoutes(app) {
  router.post("/create", authenticationToken, createDepartment);
  router.get(
    "/get-all", authenticationToken,
    app.set("name", "get-all-department"),
    getAlDepartment
  );
  router.get("/get-with-rule", authenticationToken, getDepartmentWithRule);
  router.post("/check-permission", authenticationToken, checkPermission);
  return app.use("/department", router);
};
