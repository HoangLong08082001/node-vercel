const { authenticationToken } =require ("../../middleware/JwtAction");
const { getProducts } = require ("./ProductController");

const express = require("express");
const router = express.Router();

function ProductRoutes(app) {
  router.get("/get-all", authenticationToken, getProducts);
  return app.use("/product", router);
}
module.exports = ProductRoutes;
