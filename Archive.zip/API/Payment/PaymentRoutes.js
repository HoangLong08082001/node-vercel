const express = require("express");
const { drawCommission, confirmTransfer } = require("./PaymentController");
const { authenticationToken } = require("../../middleware/JwtAction");
const router = express.Router();
module.exports = function PaymentRoutes(app) {
  router.post("/draw", authenticationToken, drawCommission);
  router.put('/confirm', confirmTransfer);
  router.get('/get-draws')
  return app.use("/commission", router);
};
