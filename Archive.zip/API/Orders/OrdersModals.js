class ServiceOrder {
  static getOrdersHaveReferralLink() {
    return "SELECT * FROM orders join commission on orders.id_orders = commission.id_orders WHERE referral_link LIKE '%/?bwaf=%' AND financial_status like 'paid' AND fulfillment_status like 'fulfilled' ";
  }
  static checkRefferalHave() {
    return "SELECT * FROM orders join commission on orders.id_orders = commission.id_orders WHERE referral_link IN ('/', '/password', '') AND financial_status like 'paid' AND fulfillment_status like 'fulfilled'";
  }
  static getAllOrders() {
    return "SELECT *, (SELECT MIN(date_delivered) FROM orders) AS min_date, (SELECT MAX(date_delivered) FROM orders) AS max_date FROM orders join commission on orders.id_orders = commission.id_orders";
  }
  static allOrders() {
    return "SELECT * FROM orders";
  }
  static filterOrders(){
    return "SELECT * FROM orders join commission on orders.id_orders = commission.id_orders WHERE ";
  }
}
module.exports = { ServiceOrder };
