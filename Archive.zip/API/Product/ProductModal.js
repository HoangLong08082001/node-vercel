class ServiceProduct {
  static all = "SELECT * FROM products";
}

module.exports = { ServiceProduct };
