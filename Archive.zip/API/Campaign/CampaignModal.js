class ServiceCampaign {
  static create() {
    return "INSERT INTO campaign (image, link_product, name_campaign, commission, description, date_start, date_end) VALUES (?,?,?,?,?,?,?)";
  }
  static getCampWithRule() {
    return "SELECT * FROM campaign JOIN campaign_products ON campaign.id_campaign = campaign_products.id_campaign JOIN products ON campaign_products.id_products = products.id_products";
  }
  static getCampaignWithProduct() {
    return "SELECT campaign.id_campaign, campaign.name_campaign, products.id_products, products.id_products_sapo, campaign.link_product, products.alias, campaign.description, campaign.date_start, campaign.date_end, campaign.commission, campaign.image, products.image_product, products.name_product FROM campaign LEFT JOIN campaign_products ON campaign.id_campaign = campaign_products.id_campaign LEFT JOIN products ON campaign_products.id_products = products.id_products";
  }
  static getCampaignById() {
    return "SELECT id_products FROM campaign_products WHERE id_campaign = ?";
  }
  static addProductIntoCampaign() {
    return "INSERT INTO campaign_products (id_campaign, id_products) VALUES ?";
  }
  static deleteCampaignByIdCamAndProduct(){
    return "DELETE FROM campaign_products WHERE id_campaign = ? AND id_products IN (?)";
  }
}
module.exports = { ServiceCampaign };
