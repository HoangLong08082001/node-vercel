const { authenticationToken } = require("../../middleware/JwtAction");
const {
  CraeteRule,
  GetRule,
  UpdateRule,
  DeleteRule,
} = require("./RuleController");

const express = require("express");
const router = express.Router();
function RuleRoute(app) {
  router.post("/create", authenticationToken, (req, res) => CraeteRule(req, res, req.app.get("io")));
  router.get("/get-all", authenticationToken, GetRule);
  router.put("/update", authenticationToken, (req, res) => UpdateRule(req, res, req.app.get("io")));
  router.delete("/delete", authenticationToken, DeleteRule);
  return app.use("/rule", router);
}
module.exports = RuleRoute;
