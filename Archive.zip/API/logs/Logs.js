const express = require("express");
const fs = require("fs");

const router = express.Route();
function Logs(app) {
  router.get("/logs", (req, res) => {
    const logFilePath = path.join(__dirname, "combined.log");
    fs.readFile(logFilePath, "utf8", (err, data) => {
      if (err) {
        throw err;
      }
      if (data) {
        try {
          const logsLine = data
            .split("\n")
            .filter((line) => line.trim() !== "");
          const logObject = logsLine.map((item) => JSON.parse(item));
          console.log(logObject);
          return res.status(200).json(logObject);
        } catch (error) {
          return res.status(500).json({ message: "fails" });
        }
      }
    });
  });
  return app.use("/");
}
module.exports = Logs;
